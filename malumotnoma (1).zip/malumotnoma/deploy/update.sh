#!/usr/bin/env bash
# =============================================================================
#  Ma'lumotnoma platformasi — yangi versiyani o'rnatish (baza va sozlamalar saqlanadi)
#  Ishlatish: yangi zip'ni ochib, o'sha papkadan:  sudo bash deploy/update.sh
# =============================================================================
set -euo pipefail
APP=malumotnoma
APP_DIR=/opt/malumotnoma
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ok()   { printf '\033[1;32m✔ %s\033[0m\n' "$*"; }
die()  { printf '\033[1;31m✘ %s\033[0m\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Root sifatida ishga tushiring: sudo bash deploy/update.sh"
[[ -f /etc/malumotnoma/env ]] || die "Avval o'rnatish kerak: sudo bash deploy/install.sh"
[[ "$SRC_DIR" != "$APP_DIR" ]] || die "Skriptni yangi versiya papkasidan ishga tushiring, $APP_DIR dan emas"

/usr/local/bin/malumotnoma-backup && ok "Yangilashdan oldin zaxira olindi"

rsync -a --delete \
  --exclude venv --exclude .venv --exclude .env --exclude 'db.sqlite3*' --exclude staticfiles \
  --exclude __pycache__ --exclude '*.pyc' --exclude .git \
  "$SRC_DIR"/ "$APP_DIR"/
chown -R root:root "$APP_DIR"
"$APP_DIR/venv/bin/pip" install -q -r "$APP_DIR/requirements.txt"
malumotnoma-manage migrate --noinput
malumotnoma-manage collectstatic --noinput -v0
malumotnoma-manage check --deploy --fail-level ERROR >/dev/null 2>&1

if [[ -d /run/systemd/system ]]; then systemctl restart $APP; else pkill -HUP -f "gunicorn config.wsgi" || true; fi
sleep 2
DOMAIN=$(grep -oP '^DJANGO_ALLOWED_HOSTS="\K[^,"]+' /etc/malumotnoma/env)
curl -fsS -H "Host: $DOMAIN" http://127.0.0.1/healthz | grep -q '"ok"' && ok "Yangilandi va ishlayapti" || die "Sayt javob bermayapti: journalctl -u $APP -n 50"
