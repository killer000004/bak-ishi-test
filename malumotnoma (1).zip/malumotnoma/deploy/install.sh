#!/usr/bin/env bash
# =============================================================================
#  Ma'lumotnoma platformasi — Ubuntu 22.04 / 24.04 serverga o'rnatish
#
#  Ishlatish (loyiha papkasidan):
#      sudo bash deploy/install.sh
#
#  Ikki rejim:
#    proxy  — sayt SafeLine WAF / Nginx Proxy Manager ortida (HTTPS'ni WAF beradi)
#    direct — server internetga to'g'ridan-to'g'ri chiqadi (HTTPS: Let's Encrypt)
#
#  Savollarsiz ishlatish uchun o'zgaruvchilarni oldindan bering, masalan:
#      sudo DOMAIN=malumotnoma.uzkip.com MODE=proxy PROXY_IP=10.166.115.10 bash deploy/install.sh
# =============================================================================
set -euo pipefail

APP=malumotnoma
APP_USER=malumotnoma
APP_DIR=/opt/malumotnoma
DATA_DIR=/var/lib/malumotnoma
BACKUP_DIR=/var/backups/malumotnoma
STATIC_DIR=/var/www/malumotnoma/static
ENV_DIR=/etc/malumotnoma
ENV_FILE=$ENV_DIR/env
PORT=8001
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

c_ok()   { printf '\033[1;32m✔ %s\033[0m\n' "$*"; }
c_info() { printf '\033[1;34m➜ %s\033[0m\n' "$*"; }
c_warn() { printf '\033[1;33m⚠ %s\033[0m\n' "$*"; }
die()    { printf '\033[1;31m✘ %s\033[0m\n' "$*" >&2; exit 1; }
ask() {  # ask VAR "Savol" "standart"
  local var=$1 q=$2 def=${3:-} cur=${!1:-}
  if [[ -n "$cur" ]]; then return; fi
  if [[ -t 0 ]]; then
    read -r -p "$q${def:+ [$def]}: " ans || true
    printf -v "$var" '%s' "${ans:-$def}"
  else
    printf -v "$var" '%s' "$def"
  fi
}
safe() {  # env faylini buzadigan belgilarni rad etish
  [[ "$1" != *'"'* && "$1" != *'$'* && "$1" != *'`'* && "$1" != *'\'* ]] || die "Qiymatda \" \$ \` \\ belgilari bo'lmasin: $1"
}
has_systemd() { [[ -d /run/systemd/system ]]; }

# ---------- 0. Tekshiruvlar ----------
[[ $EUID -eq 0 ]] || die "Root sifatida ishga tushiring: sudo bash deploy/install.sh"
[[ -f "$SRC_DIR/manage.py" ]] || die "Loyiha papkasi topilmadi ($SRC_DIR)"
. /etc/os-release
[[ "${ID:-}" == "ubuntu" || "${ID_LIKE:-}" == *debian* ]] || c_warn "Bu skript Ubuntu uchun yozilgan (sizda: ${PRETTY_NAME:-aniqlanmadi})"

echo
echo "================  Ma'lumotnoma platformasini o'rnatish  ================"
echo

# ---------- 1. Sozlamalar ----------
ask DOMAIN    "Sayt domeni (masalan malumotnoma.uzkip.com)" ""
[[ -n "$DOMAIN" ]] || die "Domen kiritilmadi"
ask MODE      "Rejim: proxy (WAF ortida) yoki direct (to'g'ridan, Let's Encrypt)" "proxy"
[[ "$MODE" == "proxy" || "$MODE" == "direct" ]] || die "MODE faqat proxy yoki direct bo'lishi mumkin"
if [[ "$MODE" == "proxy" ]]; then
  ask PROXY_IP "WAF / reverse proxy IP manzili" "10.166.115.10"
  ask ALLOW_NETS "Saytga to'g'ridan kira oladigan ichki tarmoqlar (bo'sh joy bilan)" "10.166.0.0/16"
else
  ask LE_EMAIL "Let's Encrypt uchun email" ""
  [[ -n "$LE_EMAIL" ]] || die "Email kiritilmadi"
fi
ask SITE_TITLE "Sayt nomi" "Talabalar ma'lumotnomasi"
ask ORG_NAME   "Tashkilot nomi (footerda)" ""
ask FIREWALL   "UFW firewall yoqilsinmi? (yes/no)" "yes"
for v in "$DOMAIN" "$SITE_TITLE" "$ORG_NAME"; do safe "$v"; done

SERVER_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
c_info "Domen: $DOMAIN | Rejim: $MODE | Server IP: ${SERVER_IP:-?}"

# ---------- 2. Paketlar ----------
c_info "Tizim paketlari o'rnatilmoqda..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
PKGS=(python3 python3-venv python3-pip nginx sqlite3 rsync curl)
[[ "$MODE" == "direct" ]] && PKGS+=(certbot python3-certbot-nginx)
[[ "$FIREWALL" == "yes" ]] && PKGS+=(ufw)
apt-get install -y -qq "${PKGS[@]}" >/dev/null
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)' || die "Python 3.10+ kerak"
c_ok "Paketlar tayyor"

# ---------- 3. Foydalanuvchi va papkalar ----------
id -u "$APP_USER" >/dev/null 2>&1 || useradd --system --home "$DATA_DIR" --shell /usr/sbin/nologin "$APP_USER"
install -d -o "$APP_USER" -g "$APP_USER" -m 750 "$DATA_DIR"
install -d -o root -g root -m 700 "$BACKUP_DIR"
install -d -o root -g "$APP_USER" -m 750 "$ENV_DIR"
install -d -o "$APP_USER" -g www-data -m 755 "$STATIC_DIR"
install -d -o root -g root -m 755 "$APP_DIR"

# ---------- 4. Kod ----------
c_info "Kod $APP_DIR ga ko'chirilmoqda..."
rsync -a --delete \
  --exclude venv --exclude .venv --exclude .env --exclude 'db.sqlite3*' --exclude staticfiles \
  --exclude __pycache__ --exclude '*.pyc' --exclude .git \
  "$SRC_DIR"/ "$APP_DIR"/
chown -R root:root "$APP_DIR"
c_ok "Kod ko'chirildi"

c_info "Python muhiti (venv) tayyorlanmoqda..."
[[ -x "$APP_DIR/venv/bin/python" ]] || python3 -m venv "$APP_DIR/venv"
"$APP_DIR/venv/bin/pip" install -q --upgrade pip
"$APP_DIR/venv/bin/pip" install -q -r "$APP_DIR/requirements.txt"
c_ok "Python kutubxonalari o'rnatildi"

# ---------- 5. Maxfiy sozlamalar (env) ----------
HOSTS="$DOMAIN,localhost,127.0.0.1${SERVER_IP:+,$SERVER_IP}"
if [[ ! -f "$ENV_FILE" ]]; then
  SECRET=$("$APP_DIR/venv/bin/python" -c 'import secrets; print(secrets.token_urlsafe(50))')
  cat > "$ENV_FILE" <<EOF
# Ma'lumotnoma platformasi sozlamalari (install.sh yaratgan). O'zgartirgach: systemctl restart $APP
DJANGO_DEBUG="0"
DJANGO_SECRET_KEY="$SECRET"
DJANGO_ALLOWED_HOSTS="$HOSTS"
DJANGO_CSRF_TRUSTED_ORIGINS="https://$DOMAIN"
SITE_TITLE="$SITE_TITLE"
ORG_NAME="$ORG_NAME"
DB_PATH="$DATA_DIR/db.sqlite3"
STATIC_ROOT="$STATIC_DIR"
EOF
  c_ok "Yangi maxfiy kalit bilan $ENV_FILE yaratildi"
else
  c_warn "$ENV_FILE allaqachon bor — o'zgartirilmadi (maxfiy kalit saqlanib qoldi)"
fi
chown root:"$APP_USER" "$ENV_FILE"; chmod 640 "$ENV_FILE"

# ---------- 6. Boshqaruv buyrug'i: malumotnoma-manage ----------
cat > /usr/local/bin/malumotnoma-manage <<EOF
#!/usr/bin/env bash
# Django manage.py ni to'g'ri foydalanuvchi va sozlamalar bilan ishga tushiradi.
# Masalan: sudo malumotnoma-manage createsuperuser
exec runuser -u $APP_USER -- bash -c 'set -a; . $ENV_FILE; set +a; cd $APP_DIR; exec venv/bin/python manage.py "\$@"' _ "\$@"
EOF
chmod 755 /usr/local/bin/malumotnoma-manage

c_info "Baza va statik fayllar..."
malumotnoma-manage migrate --noinput -v0
chmod 640 "$DATA_DIR"/db.sqlite3* 2>/dev/null || true
malumotnoma-manage collectstatic --noinput -v0
malumotnoma-manage check --deploy --fail-level ERROR >/dev/null 2>&1 || die "Django sozlamalarida xato: sudo malumotnoma-manage check --deploy"
c_ok "Baza tayyor: $DATA_DIR/db.sqlite3"

# ---------- 7. Gunicorn (systemd xizmati) ----------
CPUS=$(nproc 2>/dev/null || echo 1); WORKERS=$(( CPUS * 2 + 1 )); (( WORKERS > 5 )) && WORKERS=5
cat > /etc/systemd/system/$APP.service <<EOF
[Unit]
Description=Ma'lumotnoma platformasi (Django + Gunicorn)
After=network.target

[Service]
Type=simple
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$APP_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$APP_DIR/venv/bin/gunicorn config.wsgi:application --bind 127.0.0.1:$PORT --workers $WORKERS --timeout 120 --access-logfile - --error-logfile -
Restart=always
RestartSec=3
UMask=0027
# Xavfsizlik cheklovlari
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$DATA_DIR
ProtectKernelTunables=true
ProtectControlGroups=true
RestrictSUIDSGID=true

[Install]
WantedBy=multi-user.target
EOF

# ---------- 8. Nginx ----------
cat > /etc/nginx/conf.d/$APP-limits.conf <<'EOF'
# Ma'lumotnoma: parol tanlashga (brute-force) va spam yuborishga qarshi cheklovlar.
# Faqat POST (login urinishi / forma yuborish) sanaladi — sahifani ochish cheklanmaydi,
# shunda bitta NAT IP ortidagi butun sinf bir vaqtda bemalol to'ldira oladi.
map $request_method $mn_post_ip {
    POST    $binary_remote_addr;
    default "";
}
limit_req_zone $mn_post_ip zone=mn_login_post:10m rate=10r/m;
limit_req_zone $mn_post_ip zone=mn_form_post:10m  rate=60r/m;
limit_req_status 429;
EOF

LISTEN6=""
python3 -c 'import socket; s=socket.socket(socket.AF_INET6); s.close()' 2>/dev/null && LISTEN6="    listen [::]:80;"

if [[ "$MODE" == "proxy" ]]; then
  REALIP="    # Haqiqiy foydalanuvchi IP'si WAF yuborgan X-Forwarded-For dan olinadi
    set_real_ip_from $PROXY_IP;
    real_ip_header X-Forwarded-For;
    real_ip_recursive on;"
  PROTO="https"   # HTTPS'ni WAF beradi
else
  REALIP=""
  PROTO="\$scheme"
fi

mkdir -p /etc/nginx/snippets
cat > /etc/nginx/snippets/$APP-proxy.conf <<EOF
proxy_pass http://127.0.0.1:$PORT;
proxy_set_header Host \$host;
proxy_set_header X-Real-IP \$remote_addr;
proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto $PROTO;
proxy_read_timeout 130s;
EOF

cat > /etc/nginx/sites-available/$APP <<EOF
server {
    listen 80;
$LISTEN6
    server_name $DOMAIN${SERVER_IP:+ $SERVER_IP};

$REALIP

    client_max_body_size 5m;
    server_tokens off;

    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options DENY always;
    add_header Referrer-Policy same-origin always;

    gzip on;
    gzip_types text/css application/javascript application/json image/svg+xml;

    location /static/ {
        alias $STATIC_DIR/;
        expires 7d;
        access_log off;
    }

    location = /healthz { access_log off; include snippets/$APP-proxy.conf; }

    location ~ ^/(panel/kirish|admin/login)/ {
        limit_req zone=mn_login_post burst=10 nodelay;
        include snippets/$APP-proxy.conf;
    }

    location /toldirish/ {
        limit_req zone=mn_form_post burst=40 nodelay;
        include snippets/$APP-proxy.conf;
    }

    location / {
        include snippets/$APP-proxy.conf;
    }
}
EOF
ln -sf /etc/nginx/sites-available/$APP /etc/nginx/sites-enabled/$APP
rm -f /etc/nginx/sites-enabled/default   # Ubuntu'ning namunaviy sayti kerak emas
nginx -t -q || die "Nginx sozlamasida xato (yuqoriga qarang)"
c_ok "Nginx sozlandi"

# ---------- 9. Xizmatlarni ishga tushirish ----------
if has_systemd; then
  systemctl daemon-reload
  systemctl enable --now $APP >/dev/null 2>&1
  systemctl restart $APP
  systemctl enable nginx >/dev/null 2>&1
  systemctl restart nginx
else
  c_warn "systemd topilmadi (konteyner?) — xizmatlar qo'lda ishga tushirilmoqda"
  pkill -f "gunicorn config.wsgi" 2>/dev/null || true
  runuser -u $APP_USER -- bash -c "set -a; . $ENV_FILE; set +a; cd $APP_DIR; nohup venv/bin/gunicorn config.wsgi:application --bind 127.0.0.1:$PORT --workers 2 --timeout 120 > /tmp/$APP-gunicorn.log 2>&1 &"
  (nginx -s quit 2>/dev/null; sleep 1; nginx)
fi
sleep 2

# ---------- 10. HTTPS (faqat direct rejim) ----------
if [[ "$MODE" == "direct" ]]; then
  c_info "Let's Encrypt sertifikati olinmoqda..."
  if certbot --nginx -d "$DOMAIN" -m "$LE_EMAIL" --agree-tos -n --redirect; then
    c_ok "HTTPS yoqildi (sertifikat avtomatik yangilanadi)"
  else
    c_warn "Sertifikat olinmadi. DNS A yozuvi shu serverga qaraganini va 80-port ochiqligini tekshiring, keyin: certbot --nginx -d $DOMAIN"
  fi
fi

# ---------- 11. Firewall ----------
if [[ "$FIREWALL" == "yes" ]] && command -v ufw >/dev/null; then
  SSH_PORT=$(sshd -T 2>/dev/null | awk '/^port /{print $2; exit}'); SSH_PORT=${SSH_PORT:-22}
  ufw allow "$SSH_PORT"/tcp comment 'SSH' >/dev/null
  if [[ "$MODE" == "proxy" ]]; then
    ufw allow from "$PROXY_IP" to any port 80 proto tcp comment 'WAF' >/dev/null
    for n in $ALLOW_NETS; do ufw allow from "$n" to any port 80 proto tcp comment 'ichki tarmoq' >/dev/null; done
  else
    ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null
  fi
  if has_systemd; then ufw --force enable >/dev/null && c_ok "UFW yoqildi (SSH port $SSH_PORT ochiq qoldirildi)"; fi
fi

# ---------- 12. Har kungi zaxira nusxa ----------
cat > /usr/local/bin/malumotnoma-backup <<EOF
#!/usr/bin/env bash
# Bazaning zaxira nusxasi: $BACKUP_DIR (30 kun saqlanadi)
set -euo pipefail
F="$BACKUP_DIR/db-\$(date +%F_%H%M).sqlite3"
sqlite3 "$DATA_DIR/db.sqlite3" ".backup '\$F'"
gzip -f "\$F"
find "$BACKUP_DIR" -name 'db-*.sqlite3.gz' -mtime +30 -delete
echo "Zaxira: \$F.gz"
EOF
chmod 750 /usr/local/bin/malumotnoma-backup
echo "30 0 * * * root /usr/local/bin/malumotnoma-backup >/dev/null 2>&1" > /etc/cron.d/$APP
c_ok "Har kuni 00:30 da zaxira olinadi → $BACKUP_DIR"

# ---------- 13. Tekshiruv ----------
if curl -fsS -H "Host: $DOMAIN" http://127.0.0.1/healthz | grep -q '"ok"'; then
  c_ok "Sayt ishlayapti (http://127.0.0.1/healthz → ok)"
else
  c_warn "Sayt javob bermadi. Loglar: journalctl -u $APP -n 50"
fi

# ---------- 14. Administrator ----------
HAS_SU=$(malumotnoma-manage shell -c "from django.contrib.auth.models import User; print(User.objects.filter(is_superuser=True).exists())" 2>/dev/null | tail -1)
if [[ "$HAS_SU" != "True" ]]; then
  if [[ -t 0 ]]; then
    c_info "Boshqaruv paneli uchun administrator yarating:"
    malumotnoma-manage createsuperuser
  else
    c_warn "Administrator yaratilmagan. Buyruq: sudo malumotnoma-manage createsuperuser"
  fi
fi

echo
echo "========================================================================"
c_ok "O'rnatish tugadi!"
echo
if [[ "$MODE" == "proxy" ]]; then
  echo "  Keyingi qadam — WAF'da yangi sayt qo'shing:"
  echo "    Domen:     $DOMAIN"
  echo "    Upstream:  http://${SERVER_IP:-SERVER_IP}:80"
  echo "  (batafsil: DEPLOY_SERVER.md)"
else
  echo "  Sayt: https://$DOMAIN"
fi
echo
echo "  Foydali buyruqlar:"
echo "    systemctl status $APP          — holat"
echo "    journalctl -u $APP -f          — loglar"
echo "    sudo malumotnoma-manage createsuperuser   — yangi admin"
echo "    sudo malumotnoma-backup        — qo'lda zaxira"
echo "    sudo bash deploy/update.sh     — yangi versiyani o'rnatish"
echo "========================================================================"
