from django.urls import path

from . import views

app_name = "anketa"

urlpatterns = [
    path("", views.landing_view, name="landing"),
    path("toldirish/", views.anketa_view, name="form"),
    path("rahmat/", views.rahmat_view, name="rahmat"),
    path("healthz", views.healthz, name="healthz"),
]
