"""Ma'muriyat uchun o'z dizayndagi boshqaruv paneli (/panel/)."""
import re
import zipfile
from datetime import timedelta
from functools import wraps
from io import BytesIO
from urllib.parse import urlencode

from django import forms
from django.contrib import messages
from django.contrib.auth import views as auth_views
from django.contrib.auth.forms import AuthenticationForm
from django.core.paginator import Paginator
from django.db.models import Count, Prefetch, Q
from django.http import FileResponse, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_POST

from .docx_generator import generate_docx
from .models import Fakultet, Guruh, Malumotnoma
from .pdf_generator import generate_pdf
from .views import _filename, _safe


# ---------- Kirish / chiqish ----------
class StaffAuthForm(AuthenticationForm):
    def confirm_login_allowed(self, user):
        super().confirm_login_allowed(user)
        if not user.is_staff:
            raise forms.ValidationError("Bu hisobda boshqaruv paneliga kirish huquqi yo'q.", code="no_staff")


class PanelLoginView(auth_views.LoginView):
    template_name = "anketa/panel/login.html"
    authentication_form = StaffAuthForm
    redirect_authenticated_user = True

    def get_default_redirect_url(self):
        return reverse("panel:dashboard")


class PanelLogoutView(auth_views.LogoutView):
    next_page = "panel:login"


def staff_required(view):
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        u = request.user
        if not (u.is_authenticated and u.is_active and u.is_staff):
            return redirect(f"{reverse('panel:login')}?{urlencode({'next': request.get_full_path()})}")
        return view(request, *args, **kwargs)
    return wrapper


# ---------- Yordamchi ----------
APOS = re.compile("[\u02BB\u02BC\u2018\u2019'`\u00B4]")
APOS_OPT = "[\u02BB\u02BC\u2018\u2019'`\u00B4]?"

def _filtered(request):
    """Qidiruv va filtrlar: ?q=...&fakultet=ID&guruh=ID|none"""
    qs = Malumotnoma.objects.select_related("guruh__fakultet")
    q = (request.GET.get("q") or "").strip()
    fak = request.GET.get("fakultet") or ""
    gr = request.GET.get("guruh") or ""
    if q:
        cond = Q()
        for word in q.split():  # har bir so'z F.I.Sh. ichida bo'lishi kerak (tartibi muhim emas)
            word = APOS.sub("", word)
            if not word:
                continue
            # oʻ/gʻ har xil yoziladi (ʻ ' ‘ ’ ` yoki umuman yo'q) — har bir harfdan keyin tutuq belgisi ixtiyoriy
            pattern = APOS_OPT.join(re.escape(ch) for ch in word)
            cond &= Q(fish__iregex=pattern)
        digits = "".join(ch for ch in q if ch.isdigit())
        if len(digits) >= 4:
            cond |= Q(telefon__icontains=digits)
        qs = qs.filter(cond)
    if fak.isdigit():
        qs = qs.filter(guruh__fakultet_id=int(fak))
    if gr == "none":
        qs = qs.filter(guruh__isnull=True)
    elif gr.isdigit():
        qs = qs.filter(guruh_id=int(gr))
    return qs, {"q": q, "fakultet": fak, "guruh": gr}


# ---------- Sahifalar ----------
@staff_required
def dashboard(request):
    now = timezone.localtime()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    total = Malumotnoma.objects.count()
    stats = {
        "jami": total,
        "bugun": Malumotnoma.objects.filter(yaratilgan__gte=today).count(),
        "hafta": Malumotnoma.objects.filter(yaratilgan__gte=today - timedelta(days=6)).count(),
        "guruhlar": Guruh.objects.count(),
    }
    guruhlar = (Guruh.objects.select_related("fakultet")
                .annotate(soni=Count("malumotnomalar")).order_by("-soni", "fakultet__nomi", "nomi"))
    maks = max([g.soni for g in guruhlar] + [1])
    guruhsiz = Malumotnoma.objects.filter(guruh__isnull=True).count()
    oxirgilar = Malumotnoma.objects.select_related("guruh__fakultet")[:8]
    return render(request, "anketa/panel/dashboard.html", {
        "stats": stats, "guruhlar": guruhlar, "maks": maks, "guruhsiz": guruhsiz,
        "oxirgilar": oxirgilar, "nav": "dashboard",
    })


@staff_required
def talabalar(request):
    qs, f = _filtered(request)
    page = Paginator(qs, 50).get_page(request.GET.get("page"))
    params = urlencode({k: v for k, v in f.items() if v})
    guruhlar = Guruh.objects.select_related("fakultet")
    if f["fakultet"].isdigit():
        guruhlar = guruhlar.filter(fakultet_id=int(f["fakultet"]))
    return render(request, "anketa/panel/list.html", {
        "page": page, "f": f, "params": params, "jami": qs.count(),
        "fakultetlar": Fakultet.objects.all(), "guruhlar": guruhlar, "nav": "talabalar",
    })


@staff_required
def talaba(request, pk):
    obj = get_object_or_404(Malumotnoma.objects.select_related("guruh__fakultet"), pk=pk)
    return render(request, "anketa/panel/detail.html", {"o": obj, "nav": "talabalar"})


@staff_required
@require_POST
def talaba_ochirish(request, pk):
    obj = get_object_or_404(Malumotnoma, pk=pk)
    name = obj.fish
    obj.delete()
    messages.success(request, f"{name} — ma'lumotnoma o'chirildi.")
    return redirect("panel:talabalar")


@staff_required
def pdf_view(request, pk):
    """?korish=1 — brauzerda ochish, aks holda yuklab olish."""
    obj = get_object_or_404(Malumotnoma, pk=pk)
    return FileResponse(generate_pdf(obj), as_attachment=request.GET.get("korish") != "1",
                        filename=_filename(obj, "pdf"), content_type="application/pdf")


@staff_required
def docx_view(request, pk):
    obj = get_object_or_404(Malumotnoma, pk=pk)
    return FileResponse(generate_docx(obj), as_attachment=True, filename=_filename(obj, "docx"))


@staff_required
def zip_view(request):
    """Joriy qidiruv/filtr natijalarini PDF qilib, guruhlar bo'yicha papkalarga joylab ZIP beradi."""
    qs, f = _filtered(request)
    if not qs.exists():
        messages.warning(request, "Yuklab olish uchun ma'lumotnoma topilmadi.")
        return redirect(f"{reverse('panel:talabalar')}?{urlencode({k: v for k, v in f.items() if v})}")
    buf = BytesIO()
    used = set()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for obj in qs.prefetch_related("mehnat", "qarindoshlar"):
            folder = _safe(f"{obj.guruh.nomi}") if obj.guruh else "Guruhsiz"
            name = f"{folder}/{_filename(obj, 'pdf')}"
            if name in used:
                name = name.replace(".pdf", f"_{obj.pk}.pdf")
            used.add(name)
            zf.writestr(name, generate_pdf(obj).getvalue())
    resp = HttpResponse(buf.getvalue(), content_type="application/zip")
    stamp = timezone.localtime().strftime("%Y-%m-%d")
    resp["Content-Disposition"] = f'attachment; filename="Malumotnomalar_{stamp}.zip"'
    return resp


# ---------- Fakultet va guruhlar ----------
@staff_required
def guruhlar(request):
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "add_fak":
            nomi = (request.POST.get("nomi") or "").strip()
            if not nomi:
                messages.error(request, "Fakultet nomini kiriting.")
            elif Fakultet.objects.filter(nomi__iexact=nomi).exists():
                messages.error(request, f"\"{nomi}\" fakulteti allaqachon bor.")
            else:
                Fakultet.objects.create(nomi=nomi)
                messages.success(request, f"\"{nomi}\" fakulteti qo'shildi.")
        elif action == "add_guruh":
            fak = Fakultet.objects.filter(pk=request.POST.get("fakultet") or 0).first()
            nomlar = [n.strip() for n in (request.POST.get("nomlar") or "").replace(",", "\n").splitlines() if n.strip()]
            if not fak or not nomlar:
                messages.error(request, "Fakultetni tanlang va kamida bitta guruh nomini yozing.")
            else:
                mavjud = set(fak.guruhlar.values_list("nomi", flat=True))
                yangi = [n for n in dict.fromkeys(nomlar) if n not in mavjud]
                Guruh.objects.bulk_create([Guruh(fakultet=fak, nomi=n) for n in yangi])
                msg = f"{fak.nomi}: {len(yangi)} ta guruh qo'shildi."
                if len(yangi) < len(nomlar):
                    msg += " Takrorlanganlari o'tkazib yuborildi."
                messages.success(request, msg)
        elif action == "del_guruh":
            g = Guruh.objects.filter(pk=request.POST.get("id") or 0).annotate(n=Count("malumotnomalar")).first()
            if g and g.n:
                messages.error(request, f"\"{g.nomi}\" guruhida {g.n} ta ma'lumotnoma bor — o'chirib bo'lmaydi.")
            elif g:
                g.delete()
                messages.success(request, f"\"{g.nomi}\" guruhi o'chirildi.")
        elif action == "del_fak":
            fk = Fakultet.objects.filter(pk=request.POST.get("id") or 0).first()
            if fk:
                n = Malumotnoma.objects.filter(guruh__fakultet=fk).count()
                if n:
                    messages.error(request, f"\"{fk.nomi}\" fakultetida {n} ta ma'lumotnoma bor — o'chirib bo'lmaydi.")
                else:
                    fk.delete()
                    messages.success(request, f"\"{fk.nomi}\" fakulteti o'chirildi.")
        return redirect("panel:guruhlar")

    fakultetlar = Fakultet.objects.prefetch_related(
        Prefetch("guruhlar", queryset=Guruh.objects.annotate(n=Count("malumotnomalar")))
    ).annotate(soni=Count("guruhlar__malumotnomalar"))
    return render(request, "anketa/panel/guruhlar.html", {"fakultetlar": fakultetlar, "nav": "guruhlar"})
