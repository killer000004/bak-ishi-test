from django.conf import settings


def site(request):
    return {
        "SITE_TITLE": settings.SITE_TITLE,
        "ORG_NAME": settings.ORG_NAME,
    }
