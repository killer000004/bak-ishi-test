from django.urls import path

from . import panel_views as v

app_name = "panel"

urlpatterns = [
    path("", v.dashboard, name="dashboard"),
    path("kirish/", v.PanelLoginView.as_view(), name="login"),
    path("chiqish/", v.PanelLogoutView.as_view(), name="logout"),
    path("talabalar/", v.talabalar, name="talabalar"),
    path("talabalar/zip/", v.zip_view, name="zip"),
    path("talaba/<int:pk>/", v.talaba, name="talaba"),
    path("talaba/<int:pk>/ochirish/", v.talaba_ochirish, name="ochirish"),
    path("talaba/<int:pk>/pdf/", v.pdf_view, name="pdf"),
    path("talaba/<int:pk>/docx/", v.docx_view, name="docx"),
    path("guruhlar/", v.guruhlar, name="guruhlar"),
]
