import zipfile
from io import BytesIO

from django.contrib import admin
from django.http import HttpResponse
from django.urls import reverse
from django.utils.html import format_html

from .models import Fakultet, Guruh, Malumotnoma, MehnatFaoliyati, Qarindosh
from .pdf_generator import generate_pdf
from .views import _filename

admin.site.site_header = "Ma'lumotnomalar — boshqaruv paneli"
admin.site.site_title = "Ma'lumotnomalar"
admin.site.index_title = "Talabalar ma'lumotnomalari"


class MehnatInline(admin.TabularInline):
    model = MehnatFaoliyati
    extra = 0
    fields = ["davr", "tavsif", "tartib"]


class QarindoshInline(admin.TabularInline):
    model = Qarindosh
    extra = 0
    fields = ["qarindoshligi", "fish", "tugilgan_yili_joyi", "ish_joyi", "turar_joyi", "tartib"]


class GuruhInline(admin.TabularInline):
    model = Guruh
    extra = 1


@admin.register(Fakultet)
class FakultetAdmin(admin.ModelAdmin):
    list_display = ["nomi", "tartib"]
    list_editable = ["tartib"]
    search_fields = ["nomi"]
    inlines = [GuruhInline]


@admin.register(Guruh)
class GuruhAdmin(admin.ModelAdmin):
    list_display = ["nomi", "fakultet", "tartib"]
    list_filter = ["fakultet"]
    search_fields = ["nomi"]


@admin.register(Malumotnoma)
class MalumotnomaAdmin(admin.ModelAdmin):
    # Ro'yxat: talaba F.I.Sh. va yonida yuklab olish tugmasi
    list_display = ["fish", "guruh", "pdf_tugmalar", "telefon", "yaratilgan"]
    list_display_links = ["fish"]
    list_per_page = 50

    # Qidiruv: ism / familiya / otasining ismi (har qanday tartibda, qisman yozsa ham)
    search_fields = ["fish", "telefon"]
    search_help_text = "Talabaning familiyasi, ismi yoki telefon raqami bo'yicha qidiring"

    list_filter = ["guruh__fakultet", "guruh", "malumoti", "yaratilgan"]
    list_select_related = ["guruh__fakultet"]
    date_hierarchy = "yaratilgan"
    readonly_fields = ["yaratilgan", "pdf_tugmalar"]
    inlines = [MehnatInline, QarindoshInline]
    actions = ["zip_pdf"]
    fieldsets = [
        ("Hujjat", {"fields": ["pdf_tugmalar", "yaratilgan"]}),
        ("Asosiy", {"fields": ["fish", "guruh", "hozirgi_joyi", "lavozim_sanasi", "telefon"]}),
        ("Shaxsiy ma'lumotlar", {"fields": [
            ("tugilgan_sana", "tugilgan_joyi"), ("millati", "partiyaviyligi"),
            ("malumoti", "tamomlagan"), "mutaxassisligi",
            ("ilmiy_darajasi", "ilmiy_unvoni"), "chet_tillari",
            "davlat_mukofotlari", "deputatlik",
        ]}),
    ]

    @admin.display(description="Ma'lumotnoma")
    def pdf_tugmalar(self, obj):
        if not obj.pk:
            return "-"
        pdf = reverse("panel:pdf", args=[obj.pk])
        return format_html(
            '<span style="white-space:nowrap">'
            '<a class="button" style="background:#1f5eff;color:#fff;padding:5px 12px;border-radius:4px;'
            'display:inline-block;white-space:nowrap" href="{}">&#11015; PDF yuklab olish</a>&nbsp; '
            '<a href="{}?korish=1" target="_blank">Ko\'rish</a>&nbsp;·&nbsp;'
            '<a href="{}">DOCX</a></span>',
            pdf, pdf, reverse("panel:docx", args=[obj.pk]),
        )

    @admin.action(description="Tanlanganlarni PDF (ZIP) qilib yuklab olish")
    def zip_pdf(self, request, queryset):
        buf = BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            used = set()
            for obj in queryset:
                name = _filename(obj, "pdf")
                if name in used:
                    name = name.replace(".pdf", f"_{obj.pk}.pdf")
                used.add(name)
                zf.writestr(name, generate_pdf(obj).getvalue())
        resp = HttpResponse(buf.getvalue(), content_type="application/zip")
        resp["Content-Disposition"] = 'attachment; filename="Malumotnomalar.zip"'
        return resp
