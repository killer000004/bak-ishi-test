"""Ma'lumotnoma (obyektivka) PDF generatori — asl DOC namunasidagi ko'rinishda.

Shrift: Liberation Serif (Times New Roman bilan bir xil o'lchamli, SIL OFL litsenziyasi).
Serverga LibreOffice yoki boshqa tizim kutubxonasi kerak emas — faqat `reportlab`.
"""
from io import BytesIO
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
)

from .utils import nuqtali_sana, qaratqich, uz_sana

FONT_DIR = Path(__file__).resolve().parent / "fonts"
_registered = False


def _register_fonts():
    global _registered
    if _registered:
        return
    pdfmetrics.registerFont(TTFont("TNR", str(FONT_DIR / "LiberationSerif-Regular.ttf")))
    pdfmetrics.registerFont(TTFont("TNR-Bold", str(FONT_DIR / "LiberationSerif-Bold.ttf")))
    pdfmetrics.registerFontFamily("TNR", normal="TNR", bold="TNR-Bold", italic="TNR", boldItalic="TNR-Bold")
    _registered = True


def _styles():
    base = dict(fontName="TNR", fontSize=12, leading=14, alignment=TA_LEFT)
    return {
        "n": ParagraphStyle("n", **base),
        "b": ParagraphStyle("b", **{**base, "fontName": "TNR-Bold"}),
        "title": ParagraphStyle("title", **{**base, "fontName": "TNR-Bold", "fontSize": 14,
                                            "leading": 17, "alignment": TA_CENTER, "spaceAfter": 12}),
        "name": ParagraphStyle("name", **{**base, "fontName": "TNR-Bold", "fontSize": 14,
                                          "leading": 17, "alignment": TA_CENTER}),
        "h": ParagraphStyle("h", **{**base, "fontName": "TNR-Bold", "fontSize": 14, "leading": 17,
                                    "alignment": TA_CENTER, "spaceBefore": 12, "spaceAfter": 8}),
        "hc": ParagraphStyle("hc", **{**base, "fontName": "TNR-Bold", "alignment": TA_CENTER}),
        "work": ParagraphStyle("work", **{**base, "spaceAfter": 6}),
        "th": ParagraphStyle("th", **{**base, "fontName": "TNR-Bold", "fontSize": 11,
                                      "leading": 13, "alignment": TA_CENTER}),
        "td": ParagraphStyle("td", **{**base, "fontSize": 11, "leading": 13, "alignment": TA_CENTER}),
        "tdb": ParagraphStyle("tdb", **{**base, "fontName": "TNR-Bold", "fontSize": 11,
                                        "leading": 13, "alignment": TA_CENTER}),
    }


def _t(text):
    """Foydalanuvchi matnini xavfsiz qilish (ReportLab mini-HTML uchun)."""
    return escape(str(text or "")).replace("\n", "<br/>")


def generate_pdf(obj):
    _register_fonts()
    s = _styles()
    buf = BytesIO()

    page_w = A4[0]
    left_m, right_m = 2.0 * cm, 1.2 * cm
    usable = page_w - left_m - right_m  # ~17.8 sm

    doc = SimpleDocTemplate(
        buf, pagesize=A4, leftMargin=left_m, rightMargin=right_m,
        topMargin=1.5 * cm, bottomMargin=1.5 * cm,
        title=f"Ma'lumotnoma — {obj.fish}", author="Ma'lumotnoma platformasi",
    )
    story = []

    # ===== 1-SAHIFA: sarlavha + bo'sh rasm joyi (3x4) =====
    photo_w, photo_h = 3.5 * cm, 4.5 * cm
    photo = Table([[""]], colWidths=[photo_w], rowHeights=[photo_h])
    photo.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, colors.black)]))

    left = [
        Paragraph("MA'LUMOTNOMA", s["title"]),
        Paragraph(_t(obj.fish), s["name"]),
        Paragraph(f"{_t(uz_sana(obj.lavozim_sanasi))}:", s["n"]),
        Paragraph(_t(obj.hozirgi_joyi), s["b"]),
    ]
    head = Table([[left, photo]], colWidths=[usable - photo_w, photo_w])
    head.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (0, 0), 0),
        ("RIGHTPADDING", (0, 0), (0, 0), 12),
        ("LEFTPADDING", (1, 0), (1, 0), 0), ("RIGHTPADDING", (1, 0), (1, 0), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
    ]))
    story += [head, Spacer(1, 6)]

    # ===== Shaxsiy ma'lumotlar (2 ustun) =====
    def lv(label, value, bold_value=False):
        return [Paragraph(_t(label), s["b"]), Paragraph(_t(value), s["b"] if bold_value else s["n"])]

    rows, spans = [], []
    rows.append([lv("Tug'ilgan yili:", nuqtali_sana(obj.tugilgan_sana)), lv("Tug'ilgan joyi:", obj.tugilgan_joyi)])
    rows.append([lv("Millati:", obj.millati), lv("Partiyaviyligi:", obj.partiyaviyligi)])
    rows.append([lv("Ma'lumoti:", obj.malumoti), lv("Tamomlagan:", obj.tamomlagan)])
    rows.append([Paragraph("Ma'lumoti bo'yicha mutaxassisligi:", s["b"]), Paragraph(_t(obj.mutaxassisligi), s["b"])])
    rows.append([lv("Ilmiy darajasi:", obj.ilmiy_darajasi), lv("Ilmiy unvoni:", obj.ilmiy_unvoni)])
    for label, value in [
        ("Qaysi chet tillarini biladi:", obj.chet_tillari),
        ("Davlat mukofotlari bilan taqdirlanganmi (qanaqa):", obj.davlat_mukofotlari),
        ("Xalq deputatlari, respublika, viloyat, shahar va tuman Kengashi deputati yoki boshqa "
         "saylanadigan organlarning a'zosimi (to'liq ko'rsatilishi lozim)", obj.deputatlik),
    ]:
        spans.append(len(rows))
        rows.append([lv(label, value), ""])

    info = Table(rows, colWidths=[usable / 2, usable / 2])
    st = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    st += [("SPAN", (0, r), (1, r)) for r in spans]
    info.setStyle(TableStyle(st))
    story.append(info)

    # ===== MEHNAT FAOLIYATI =====
    story.append(Paragraph("MEHNAT FAOLIYATI", s["h"]))
    for m in obj.mehnat.all():
        story.append(Paragraph(f"<b>{_t(m.davr)}</b> {_t(m.tavsif)}", s["work"]))

    # ===== 2-SAHIFA: QARINDOSHLAR =====
    story.append(PageBreak())
    story.append(Paragraph(f"{_t(qaratqich(obj.fish))} yaqin qarindoshlari haqida", s["hc"]))
    story.append(Paragraph("MA'LUMOT", s["hc"]))
    story.append(Spacer(1, 8))

    data = [[Paragraph(h, s["th"]) for h in (
        "Qarindoshligi", "Familiyasi, ismi, otasining ismi", "Tug'ilgan yili va joyi",
        "Ish joyi va lavozimi", "Turar joyi")]]
    for q in obj.qarindoshlar.all():
        data.append([
            Paragraph(_t(q.qarindoshligi), s["tdb"]),
            Paragraph(_t(q.fish), s["td"]),
            Paragraph(_t(q.tugilgan_yili_joyi), s["td"]),
            Paragraph(_t(q.ish_joyi), s["td"]),
            Paragraph(_t(q.turar_joyi), s["td"]),
        ])
    widths = [2.6, 3.6, 3.6, 3.8, 4.2]
    k = usable / (sum(widths) * cm)
    rel = Table(data, colWidths=[w * cm * k for w in widths], repeatRows=1)
    rel.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.6, colors.black),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
    ]))
    story.append(rel)

    doc.build(story)
    buf.seek(0)
    return buf
