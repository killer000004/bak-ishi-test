from django.db import connection, transaction
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render

from .forms import MalumotnomaForm, MehnatInline, QarindoshInline
from .models import Fakultet, Guruh, Malumotnoma


def landing_view(request):
    return render(request, "anketa/landing.html")


def _guruh_data():
    fak = list(Fakultet.objects.filter(guruhlar__isnull=False).distinct().values("id", "nomi"))
    gr = list(Guruh.objects.values("id", "nomi", "fakultet_id"))
    return {"fakultetlar": fak, "guruhlar": gr}


def anketa_view(request):
    """Talaba uchun bosqichma-bosqich (savol-javob) forma.
    Yuborilgandan keyin ma'lumot faqat admin panelda ko'rinadi."""
    if request.method == "POST":
        form = MalumotnomaForm(request.POST)
        mehnat = MehnatInline(request.POST, prefix="mehnat")
        qarindosh = QarindoshInline(request.POST, prefix="qarindosh")
        if form.is_valid() and mehnat.is_valid() and qarindosh.is_valid():
            with transaction.atomic():
                obj = form.save()
                for fs in (mehnat, qarindosh):
                    fs.instance = obj
                    for i, item in enumerate(fs.save(commit=False)):
                        item.tartib = i
                        item.save()
            return redirect("anketa:rahmat")
    else:
        form = MalumotnomaForm()
        mehnat = MehnatInline(prefix="mehnat")
        qarindosh = QarindoshInline(prefix="qarindosh")

    return render(request, "anketa/wizard.html", {
        "form": form, "mehnat": mehnat, "qarindosh": qarindosh,
        "has_errors": request.method == "POST",
        "guruh_data": _guruh_data(),
    })


def healthz(request):
    """Monitoring (Zabbix / WAF) uchun: sayt va baza ishlayotganini tekshiradi."""
    try:
        with connection.cursor() as c:
            c.execute("SELECT 1")
        return JsonResponse({"status": "ok"})
    except Exception:
        return JsonResponse({"status": "db_error"}, status=503)


def rahmat_view(request):
    return render(request, "anketa/rahmat.html")


def _safe(text):
    return "".join(ch for ch in text if ch.isalnum() or ch in " _-").strip().replace(" ", "_")


def _filename(obj, ext):
    return f"Malumotnoma_{_safe(obj.fish) or obj.pk}.{ext}"
