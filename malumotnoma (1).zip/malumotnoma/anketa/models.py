from django.db import models


class Fakultet(models.Model):
    nomi = models.CharField("Fakultet nomi", max_length=200, unique=True)
    tartib = models.PositiveSmallIntegerField("Tartib", default=0)

    class Meta:
        verbose_name = "Fakultet"
        verbose_name_plural = "Fakultetlar"
        ordering = ["tartib", "nomi"]

    def __str__(self):
        return self.nomi


class Guruh(models.Model):
    fakultet = models.ForeignKey(Fakultet, on_delete=models.CASCADE, related_name="guruhlar",
                                 verbose_name="Fakultet")
    nomi = models.CharField("Guruh nomi", max_length=100)
    tartib = models.PositiveSmallIntegerField("Tartib", default=0)

    class Meta:
        verbose_name = "Guruh"
        verbose_name_plural = "Guruhlar"
        ordering = ["fakultet__tartib", "fakultet__nomi", "tartib", "nomi"]
        constraints = [models.UniqueConstraint(fields=["fakultet", "nomi"], name="uniq_guruh_fakultet")]

    def __str__(self):
        return f"{self.nomi} ({self.fakultet.nomi})"


class Malumotnoma(models.Model):
    MALUMOT_CHOICES = [
        ("Oliy", "Oliy"),
        ("Oliy (tugallanmagan)", "Oliy (tugallanmagan)"),
        ("O'rta maxsus", "O'rta maxsus"),
        ("O'rta", "O'rta"),
    ]

    fish = models.CharField("Familiyasi, ismi, otasining ismi", max_length=255, db_index=True)
    guruh = models.ForeignKey(Guruh, on_delete=models.SET_NULL, null=True, blank=True,
                              related_name="malumotnomalar", verbose_name="Guruh")
    lavozim_sanasi = models.DateField("Hozirgi ish/o'qish joyiga kirgan sana")
    hozirgi_joyi = models.TextField("Hozirgi ish/o'qish joyi va lavozimi")

    tugilgan_sana = models.DateField("Tug'ilgan sanasi")
    tugilgan_joyi = models.CharField("Tug'ilgan joyi", max_length=255)
    millati = models.CharField("Millati", max_length=100)
    partiyaviyligi = models.CharField("Partiyaviyligi", max_length=100, default="partiyasiz")

    malumoti = models.CharField("Ma'lumoti", max_length=50, choices=MALUMOT_CHOICES)
    tamomlagan = models.CharField(
        "Tamomlagan (yili va o'quv yurti)", max_length=255,
        help_text="Masalan: 2015 yil G'ozovot kasb-hunar kolleji",
    )
    mutaxassisligi = models.CharField("Ma'lumoti bo'yicha mutaxassisligi", max_length=255)

    ilmiy_darajasi = models.CharField("Ilmiy darajasi", max_length=100, default="Ega emas")
    ilmiy_unvoni = models.CharField("Ilmiy unvoni", max_length=100, default="Ega emas")
    chet_tillari = models.CharField("Qaysi chet tillarini biladi", max_length=255)
    davlat_mukofotlari = models.CharField(
        "Davlat mukofotlari bilan taqdirlanganmi (qanaqa)", max_length=255, default="yo'q"
    )
    deputatlik = models.CharField(
        "Deputatlik yoki boshqa saylanadigan organlar a'zoligi", max_length=255, default="yo'q"
    )

    telefon = models.CharField("Telefon raqami", max_length=30, blank=True)
    yaratilgan = models.DateTimeField("Yuborilgan vaqti", auto_now_add=True)

    class Meta:
        verbose_name = "Ma'lumotnoma"
        verbose_name_plural = "Ma'lumotnomalar"
        ordering = ["-yaratilgan"]

    def __str__(self):
        return self.fish


class MehnatFaoliyati(models.Model):
    malumotnoma = models.ForeignKey(
        Malumotnoma, on_delete=models.CASCADE, related_name="mehnat"
    )
    davr = models.CharField("Davr", max_length=50, help_text="Masalan: 2012-2015 y.y. yoki 2021 y.-h.v.")
    tavsif = models.CharField("Ish/o'qish joyi va lavozimi", max_length=500)
    tartib = models.PositiveSmallIntegerField(default=0)

    class Meta:
        verbose_name = "Mehnat faoliyati"
        verbose_name_plural = "Mehnat faoliyati"
        ordering = ["tartib", "id"]

    def __str__(self):
        return f"{self.davr} {self.tavsif}"


class Qarindosh(models.Model):
    QARINDOSHLIK_CHOICES = [
        ("Otasi", "Otasi"),
        ("Onasi", "Onasi"),
        ("Akasi", "Akasi"),
        ("Ukasi", "Ukasi"),
        ("Opasi", "Opasi"),
        ("Singlisi", "Singlisi"),
        ("Turmush o'rtog'i", "Turmush o'rtog'i"),
        ("O'g'li", "O'g'li"),
        ("Qizi", "Qizi"),
    ]

    malumotnoma = models.ForeignKey(
        Malumotnoma, on_delete=models.CASCADE, related_name="qarindoshlar"
    )
    qarindoshligi = models.CharField("Qarindoshligi", max_length=50, choices=QARINDOSHLIK_CHOICES)
    fish = models.CharField("Familiyasi, ismi, otasining ismi", max_length=255)
    tugilgan_yili_joyi = models.CharField("Tug'ilgan yili va joyi", max_length=255)
    ish_joyi = models.CharField("Ish joyi va lavozimi", max_length=255)
    turar_joyi = models.CharField("Turar joyi", max_length=255)
    tartib = models.PositiveSmallIntegerField(default=0)

    class Meta:
        verbose_name = "Qarindosh"
        verbose_name_plural = "Yaqin qarindoshlar"
        ordering = ["tartib", "id"]

    def __str__(self):
        return f"{self.qarindoshligi}: {self.fish}"
