"""Ma'lumotnoma (obyektivka) DOCX generatori — asl namunadagi ko'rinishda."""
from io import BytesIO

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT, WD_ROW_HEIGHT_RULE
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

from .utils import nuqtali_sana, qaratqich, uz_sana

FONT = "Times New Roman"


# ---------- yordamchi funksiyalar ----------
def _set_cell_borders(cell, val="single", sz=4):
    tcPr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for edge in ("top", "left", "bottom", "right"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), val)
        el.set(qn("w:sz"), str(sz))
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), "000000")
        borders.append(el)
    tcPr.append(borders)


def _no_table_borders(table):
    tblPr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "nil")
        borders.append(el)
    tblPr.append(borders)


def _cell_margins(table, left=60, right=60, top=0, bottom=0):
    tblPr = table._tbl.tblPr
    mar = OxmlElement("w:tblCellMar")
    for name, v in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        el = OxmlElement(f"w:{name}")
        el.set(qn("w:w"), str(v))
        el.set(qn("w:type"), "dxa")
        mar.append(el)
    tblPr.append(mar)


def _widths(table, widths_cm):
    table.autofit = False
    for idx, w in enumerate(widths_cm):
        table.columns[idx].width = Cm(w)
    tblPr = table._tbl.tblPr
    tw = OxmlElement("w:tblW")
    tw.set(qn("w:w"), str(int(sum(widths_cm) * 567)))
    tw.set(qn("w:type"), "dxa")
    for old in tblPr.findall(qn("w:tblW")):
        tblPr.remove(old)
    tblPr.append(tw)
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tblPr.append(layout)
    for row in table.rows:
        for idx, w in enumerate(widths_cm):
            row.cells[idx].width = Cm(w)


def _p(container, text="", bold=False, size=12, align=None, space_after=0, space_before=0):
    """Paragraf qo'shish (cell yoki document)."""
    if hasattr(container, "paragraphs") and container.paragraphs and not container.paragraphs[0].text \
            and not container.paragraphs[0].runs and getattr(container, "_tc", None) is not None:
        p = container.paragraphs[0]  # cell ichidagi bo'sh birinchi paragrafni ishlatamiz
    else:
        p = container.add_paragraph()
    pf = p.paragraph_format
    pf.space_after = Pt(space_after)
    pf.space_before = Pt(space_before)
    pf.line_spacing = 1.0
    if align is not None:
        p.alignment = align
    if text:
        _run(p, text, bold=bold, size=size)
    return p


def _run(p, text, bold=False, size=12):
    r = p.add_run(text)
    r.bold = bold
    r.font.size = Pt(size)
    r.font.name = FONT
    r._element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    return r


def _label_value(cell, label, value, value_bold=False):
    _p(cell, label, bold=True)
    _p(cell, value or "", bold=value_bold)


# ---------- asosiy generator ----------
def generate_docx(obj):
    doc = Document()

    # Standart shrift
    st = doc.styles["Normal"]
    st.font.name = FONT
    st.font.size = Pt(12)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)

    sec = doc.sections[0]
    sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
    sec.top_margin = Cm(1.5)
    sec.bottom_margin = Cm(1.5)
    sec.left_margin = Cm(2.0)
    sec.right_margin = Cm(1.2)

    # ===== 1-SAHIFA: sarlavha + rasm joyi =====
    head = doc.add_table(rows=1, cols=2)
    head.alignment = WD_TABLE_ALIGNMENT.CENTER
    _no_table_borders(head)
    _cell_margins(head)
    _widths(head, [14.3, 3.5])
    left, photo = head.rows[0].cells

    _p(left, "MA'LUMOTNOMA", bold=True, size=14, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=12)
    _p(left, obj.fish, bold=True, size=14, align=WD_ALIGN_PARAGRAPH.CENTER)
    _p(left, f"{uz_sana(obj.lavozim_sanasi)}:")
    _p(left, obj.hozirgi_joyi, bold=True)

    # Rasm joyi (3x4) — bo'sh ramka
    photo.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
    _set_cell_borders(photo)
    head.rows[0].height = Cm(4.5)
    head.rows[0].height_rule = WD_ROW_HEIGHT_RULE.AT_LEAST
    _p(photo, "")

    # ===== shaxsiy ma'lumotlar (2 ustun) =====
    info = doc.add_table(rows=0, cols=2)
    _no_table_borders(info)
    _cell_margins(info, top=40, bottom=40)

    def row2(l_label, l_val, r_label, r_val, r_bold=False):
        c1, c2 = info.add_row().cells
        _label_value(c1, l_label, l_val)
        _label_value(c2, r_label, r_val, value_bold=r_bold)

    row2("Tug'ilgan yili:", nuqtali_sana(obj.tugilgan_sana), "Tug'ilgan joyi:", obj.tugilgan_joyi)
    row2("Millati:", obj.millati, "Partiyaviyligi:", obj.partiyaviyligi)
    row2("Ma'lumoti:", obj.malumoti, "Tamomlagan:", obj.tamomlagan)

    c1, c2 = info.add_row().cells
    _p(c1, "Ma'lumoti bo'yicha mutaxassisligi:", bold=True)
    _p(c2, obj.mutaxassisligi, bold=True)

    row2("Ilmiy darajasi:", obj.ilmiy_darajasi, "Ilmiy unvoni:", obj.ilmiy_unvoni)

    def full(label, value):
        r = info.add_row()
        c = r.cells[0].merge(r.cells[1])
        _label_value(c, label, value)

    full("Qaysi chet tillarini biladi:", obj.chet_tillari)
    full("Davlat mukofotlari bilan taqdirlanganmi (qanaqa):", obj.davlat_mukofotlari)
    full(
        "Xalq deputatlari, respublika, viloyat, shahar va tuman Kengashi deputati yoki boshqa "
        "saylanadigan organlarning a'zosimi (to'liq ko'rsatilishi lozim)",
        obj.deputatlik,
    )
    _widths(info, [8.9, 8.9])

    # ===== MEHNAT FAOLIYATI =====
    _p(doc, "MEHNAT FAOLIYATI", bold=True, size=14,
       align=WD_ALIGN_PARAGRAPH.CENTER, space_before=12, space_after=8)
    for m in obj.mehnat.all():
        p = _p(doc, space_after=6)
        p.paragraph_format.left_indent = Cm(0)
        _run(p, f"{m.davr} ", bold=True)
        _run(p, m.tavsif)

    # ===== 2-SAHIFA: QARINDOSHLAR =====
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
    _p(doc, f"{qaratqich(obj.fish)} yaqin qarindoshlari haqida",
       bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
    _p(doc, "MA'LUMOT", bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=8)

    headers = ["Qarindoshligi", "Familiyasi, ismi, otasining ismi",
               "Tug'ilgan yili va joyi", "Ish joyi va lavozimi", "Turar joyi"]
    widths = [2.6, 3.6, 3.6, 3.8, 4.2]

    t = doc.add_table(rows=1, cols=5)
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    _cell_margins(t, left=60, right=60, top=40, bottom=40)
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]
        c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        _p(c, h, bold=True, size=11, align=WD_ALIGN_PARAGRAPH.CENTER)

    for q in obj.qarindoshlar.all():
        cells = t.add_row().cells
        vals = [q.qarindoshligi, q.fish, q.tugilgan_yili_joyi, q.ish_joyi, q.turar_joyi]
        for i, v in enumerate(vals):
            cells[i].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            _p(cells[i], v, bold=(i == 0), size=11, align=WD_ALIGN_PARAGRAPH.CENTER)
    _widths(t, widths)

    buf = BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf
