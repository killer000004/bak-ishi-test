from django import forms
from django.forms import inlineformset_factory

from .models import Guruh, Malumotnoma, MehnatFaoliyati, Qarindosh


class DateInput(forms.DateInput):
    input_type = "date"


class MalumotnomaForm(forms.ModelForm):
    class Meta:
        model = Malumotnoma
        exclude = ["yaratilgan"]
        widgets = {
            "lavozim_sanasi": DateInput(),
            "tugilgan_sana": DateInput(),
            "hozirgi_joyi": forms.Textarea(attrs={"rows": 3}),
            "malumoti": forms.RadioSelect(),
        }
        placeholders = {
            "fish": "Karimov Sirojbek Qurolbek o'g'li",
            "hozirgi_joyi": "... universiteti, ... yo'nalishi 1-kurs talabasi",
            "tugilgan_joyi": "Xorazm viloyati Qo'shko'pir tumani",
            "millati": "O'zbek",
            "tamomlagan": "2015 yil G'ozovot kasb-hunar kolleji",
            "mutaxassisligi": "Dasturiy injiniring",
            "chet_tillari": "Rus tili (qisman), ingliz tili",
            "telefon": "+998 90 123 45 67",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["malumoti"].choices = Malumotnoma.MALUMOT_CHOICES  # "-----" ni olib tashlash
        g = self.fields["guruh"]
        g.queryset = Guruh.objects.select_related("fakultet")
        g.required = g.queryset.exists()  # guruhlar kiritilmagan bo'lsa, talaba to'xtab qolmasin
        g.empty_label = "— Guruhni tanlang —"
        for name, f in self.fields.items():
            if name in self.Meta.placeholders:
                f.widget.attrs["placeholder"] = self.Meta.placeholders[name]


class BaseRequiredFormSet(forms.BaseInlineFormSet):
    min_message = "Kamida bitta qator to'ldiring."

    def clean(self):
        super().clean()
        filled = [
            f for f in self.forms
            if f.cleaned_data and not f.cleaned_data.get("DELETE", False)
        ]
        if not filled:
            raise forms.ValidationError(self.min_message)


class MehnatFormSet(BaseRequiredFormSet):
    min_message = "Mehnat faoliyati bo'yicha kamida bitta qator to'ldiring."


class QarindoshFormSet(BaseRequiredFormSet):
    min_message = "Kamida bitta yaqin qarindosh ma'lumotini kiriting."


MehnatInline = inlineformset_factory(
    Malumotnoma, MehnatFaoliyati, formset=MehnatFormSet,
    fields=["davr", "tavsif"], extra=2, can_delete=False,
    widgets={
        "davr": forms.TextInput(attrs={"placeholder": "2012-2015 y.y."}),
        "tavsif": forms.TextInput(attrs={"placeholder": "G'ozovot kasb-hunar kolleji o'quvchisi"}),
    },
)

QarindoshInline = inlineformset_factory(
    Malumotnoma, Qarindosh, formset=QarindoshFormSet,
    fields=["qarindoshligi", "fish", "tugilgan_yili_joyi", "ish_joyi", "turar_joyi"],
    extra=4, can_delete=False,
    widgets={
        "fish": forms.TextInput(attrs={"placeholder": "Karimov Qurolbek Xudoberganovich"}),
        "tugilgan_yili_joyi": forms.TextInput(attrs={"placeholder": "19 mart 1974 yil, Xorazm viloyati ..."}),
        "ish_joyi": forms.TextInput(attrs={"placeholder": "Ishsiz / ish joyi va lavozimi"}),
        "turar_joyi": forms.TextInput(attrs={"placeholder": "Viloyat, tuman, mahalla, ko'cha, uy"}),
    },
)
