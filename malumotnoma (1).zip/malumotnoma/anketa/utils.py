OYLAR = [
    "yanvar", "fevral", "mart", "aprel", "may", "iyun",
    "iyul", "avgust", "sentyabr", "oktyabr", "noyabr", "dekabr",
]


def uz_sana(d):
    """2021-06-21 -> '2021 yil 21 iyun'"""
    if not d:
        return ""
    return f"{d.year} yil {d.day} {OYLAR[d.month - 1]}"


def nuqtali_sana(d):
    """1997-08-19 -> '19.08.1997'"""
    return d.strftime("%d.%m.%Y") if d else ""


def qaratqich(fish):
    """'Karimov Sirojbek Qurolbek o'g'li' -> '... o'g'lining'"""
    return f"{fish.strip()}ning"
