#!/usr/bin/env bash
# GitHub'dagi yangi versiyani o'rnatish:  sudo bash /opt/tg-manager/deploy/update.sh
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Root sifatida ishga tushiring: sudo bash $0"; exit 1; }
cd /opt/tg-manager
git pull --ff-only
venv/bin/pip install -q -r backend/requirements.txt
chown -R tgmanager:tgmanager backend
systemctl restart tg-manager
sleep 3
systemctl --no-pager --lines=5 status tg-manager
