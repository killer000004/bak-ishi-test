#!/usr/bin/env bash
# TG Manager: Ubuntu 22.04 / 24.04 ga o'rnatish.
# Repo /opt/tg-manager ga clone qilingan bo'lishi kerak. Ishlatish:
#   sudo bash /opt/tg-manager/deploy/install.sh
# Sozlanadigan qiymatlar (ixtiyoriy):
#   sudo WAF_IP=10.166.115.10 ADMIN_NET=10.10.10.0/24 bash deploy/install.sh
set -euo pipefail

APP_DIR=/opt/tg-manager
APP_USER=tgmanager
PORT=8000
WAF_IP="${WAF_IP:-10.166.115.10}"        # SafeLine WAF: 8000-portga faqat u ulanadi
ADMIN_NET="${ADMIN_NET:-10.10.10.0/24}"  # SSH: Uzkip-VPN tunnel tarmog'i

[[ $EUID -eq 0 ]] || { echo "Root sifatida ishga tushiring: sudo bash $0"; exit 1; }
REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"
[[ "$REPO_DIR" == "$APP_DIR" ]] || { echo "Repo $APP_DIR ga clone qilinishi kerak (hozir: $REPO_DIR)"; exit 1; }
cd "$APP_DIR"

echo "==> [1/6] Paketlar o'rnatilmoqda"
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3 python3-venv python3-pip git ufw >/dev/null

echo "==> [2/6] '$APP_USER' tizim foydalanuvchisi"
id -u "$APP_USER" &>/dev/null || useradd --system --home-dir "$APP_DIR" --no-create-home --shell /usr/sbin/nologin "$APP_USER"

echo "==> [3/6] Python muhiti (venv)"
[[ -d venv ]] || python3 -m venv venv
venv/bin/pip install -q --upgrade pip
venv/bin/pip install -q -r backend/requirements.txt

echo "==> [4/6] backend/.env"
ENV_FILE=backend/.env
if [[ ! -f $ENV_FILE ]]; then
    read -rp "  API_ID (my.telegram.org): " API_ID
    [[ "$API_ID" =~ ^[0-9]+$ ]] || { echo "API_ID faqat raqam bo'lishi kerak"; exit 1; }
    read -rsp "  API_HASH (ekranda ko'rinmaydi): " API_HASH; echo
    [[ "$API_HASH" =~ ^[0-9a-f]{32}$ ]] || { echo "API_HASH 32 ta hex belgi bo'lishi kerak"; exit 1; }
    TOKEN=$(venv/bin/python -c "import secrets; print(secrets.token_urlsafe(32))")
    umask 077
    cat > "$ENV_FILE" <<ENV
API_ID=$API_ID
API_HASH=$API_HASH
ADMIN_TOKEN=$TOKEN
SESSION_NAME=tg_manager
TIMEZONE=Asia/Tashkent
STATS_CACHE_SECONDS=300
ENV
    echo
    echo "  ┌──────────────────────────────────────────────────────────────┐"
    echo "  │ ADMIN_TOKEN (panelga kirish uchun). Parol menejeriga saqlang: │"
    echo "  └──────────────────────────────────────────────────────────────┘"
    echo "  $TOKEN"
    echo
else
    echo "  .env allaqachon bor, o'zgartirilmadi"
fi
chown -R "$APP_USER:$APP_USER" backend
chmod 600 "$ENV_FILE"

echo "==> [5/6] systemd servisi"
sed "s|__WAF_IP__|$WAF_IP|" deploy/tg-manager.service > /etc/systemd/system/tg-manager.service
systemctl daemon-reload
systemctl enable tg-manager >/dev/null

echo "==> [6/6] Firewall (ufw)"
ufw default deny incoming >/dev/null
ufw default allow outgoing >/dev/null
ufw allow from "$ADMIN_NET" to any port 22 proto tcp comment 'SSH: VPN' >/dev/null
CURRENT_IP="${SSH_CLIENT%% *}"
if [[ -n "$CURRENT_IP" ]]; then
    # Hozirgi SSH ulanish uzilib qolmasligi uchun
    ufw allow from "$CURRENT_IP" to any port 22 proto tcp comment 'SSH: install paytidagi IP' >/dev/null
fi
ufw allow from "$WAF_IP" to any port "$PORT" proto tcp comment 'TG Manager: faqat WAF' >/dev/null
ufw --force enable >/dev/null
ufw status numbered

cat <<NEXT

Tayyor. Keyingi qadamlar:
  1) Telegram'ga login (telefon, kod, 2FA so'raladi):
       sudo -u $APP_USER $APP_DIR/venv/bin/python $APP_DIR/backend/login.py
  2) Servisni ishga tushirish:
       sudo systemctl start tg-manager
       sudo journalctl -u tg-manager -n 20 --no-pager
NEXT
