# Telegram Manager: ishga tushirish

Panel ma'lumotlarni Telegram akkauntingizdan to'g'ridan-to'g'ri oladi (Telethon, MTProto).
Frontend va backend bitta serverda ishlaydi: `http://127.0.0.1:8000`.

- **Serverga o'rnatish (VM + domen + WAF):** [DEPLOY.md](DEPLOY.md)
- **Backend'siz demo:** `demo.html` (namunaviy ma'lumotlar)
- Quyida: kompyuterda lokal ishga tushirish.

## ⚠️ Avval o'qing

- `backend/*.session` fayli **akkauntingizga to'liq kirish** beradi: xabarlar, kontaktlar, sozlamalar. Uni hech kimga bermang va git'ga qo'shmang (`.gitignore` da bor).
- Serverni `127.0.0.1` da ishga tushiring. `0.0.0.0` qilib internetga ochmang. Tashqaridan kirish kerak bo'lsa, VPN orqali kiring yoki HTTPS reverse proxy qo'ying.
- "Boshqa seanslarni yakunlash" tugmasi **telefoningizdagi Telegram'ni ham chiqarib yuboradi**. Faqat shu backend sessiyasi qoladi.
- Userbot orqali avto-javob ban xavfini oshiradi. Standart holatda u o'chiq va faqat kontaktlarga javob beradi.

## 1. API kalitlarini olish

1. https://my.telegram.org saytiga kiring (telefon raqam + Telegram'ga kelgan kod).
2. **API development tools** bo'limini oching.
3. Formani to'ldiring: `App title` va `Short name` ixtiyoriy, `Platform` uchun `Desktop` tanlang. Keyin **Create application** tugmasini bosing.
4. `App api_id` va `App api_hash` qiymatlarini ko'chirib oling.

## 2. O'rnatish

```bash
cd tg-manager/backend
python -m venv venv
# Windows:        venv\Scripts\activate
# Linux / macOS:  source venv/bin/activate
pip install -r requirements.txt
```

## 3. `.env` faylini sozlash

```bash
cp .env.example .env        # Windows: copy .env.example .env
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

`.env` faylini to'ldiring:

```
API_ID=1234567
API_HASH=0123456789abcdef0123456789abcdef
ADMIN_TOKEN=<yuqoridagi buyruq bergan token>
```

## 4. Telegram'ga login (bir marta)

```bash
python login.py
```

Tartib bilan quyidagilar so'raladi:
1. Telefon raqam (`+998...`)
2. Telegram'ga kelgan kod
3. 2FA paroli (agar yoqilgan bo'lsa)

Natijada `tg_manager.session` fayli yaratiladi.

## 5. Serverni ishga tushirish

```bash
uvicorn main:app --host 127.0.0.1 --port 8000
```

`--workers` parametrini qo'shmang: sessiya bitta, shuning uchun bitta process bo'lishi kerak.

## 6. Panelga kirish

1. Brauzerda `http://127.0.0.1:8000` ni oching.
2. **Tizim Sozlamalari** sahifasida `Access token` maydoniga `.env` dagi `ADMIN_TOKEN` ni kiriting.
3. **Saqlash va ulanish** tugmasini bosing.

Birinchi statistika 1–2 daqiqa hisoblanadi. Natija 5 daqiqa cache'da turadi. Yangi raqamlar kerak bo'lsa, **Yangilash** tugmasini bosing.

## Raqamlar qayerdan olinadi

| Panelda | Telegram manbasi |
|---|---|
| Kontaktlar | `contacts.getContacts` |
| Faol chatlar (7 kun) | Oxirgi 7 kunda xabar bo'lgan shaxsiy chat va guruhlar (kanallar kirmaydi) |
| O'qilmagan | Dialoglardagi `unread_count` |
| Boshqarilayotgan kanallar | Siz creator yoki admin bo'lgan kanallar; obunachilar `channels.getFullChannel` dan |
| Saved Messages | Jami xabarlar; fayl va media: Photo/Video + Document filtrlari |
| Yuborilgan xabarlar grafigi | Oxirgi 7 kunda sizning xabarlaringiz (shaxsiy chatlar + guruhlar) |
| Soatlar grafigi | Kiruvchi: shaxsiy chatlar; chiquvchi: shaxsiy chatlar + guruhlar |
| Seanslar | `account.getAuthorizations` |
| 2FA | `account.getPassword` |

Eski dizayndagi ikkita ko'rsatkich olib tashlandi, chunki Telegram bunday ma'lumot bermaydi:
- **"Trafik (MB)"**: API'da yo'q, u soatlar bo'yicha xabarlar grafigi bilan almashtirildi.
- **"+12 bu hafta" kontaktlar**: kontakt qo'shilgan sana API'da yo'q.

## Muammolar

| Xato | Sabab / yechim |
|---|---|
| `Telegram sessiyasi topilmadi` | Serverni to'xtating va `python login.py` ni ishga tushiring |
| `database is locked` | `login.py` server ishlab turganda ishga tushirilgan. Avval serverni to'xtating |
| `Token noto'g'ri` | Panelga kiritilgan token `.env` dagi `ADMIN_TOKEN` bilan bir xil emas |
| `Telegram cheklovi: N soniya kuting` | FloodWait. Ko'rsatilgan vaqtni kuting, "Yangilash" tugmasini tez-tez bosmang |
| `24 soatdan yangi` | Telegram yangi sessiyaga boshqa seanslarni yakunlashga 24 soat ruxsat bermaydi |
