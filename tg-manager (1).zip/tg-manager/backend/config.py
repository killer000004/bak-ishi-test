"""Sozlamalar faqat .env fayldan o'qiladi. Maxfiy kalitlar hech qachon frontendga chiqmaydi."""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"{name} .env faylida ko'rsatilmagan (namuna: .env.example)")
    return value


API_ID = int(_required("API_ID"))
API_HASH = _required("API_HASH")

ADMIN_TOKEN = _required("ADMIN_TOKEN")
if len(ADMIN_TOKEN) < 32:
    raise RuntimeError("ADMIN_TOKEN kamida 32 belgi bo'lishi kerak")

SESSION_PATH = str(BASE_DIR / os.getenv("SESSION_NAME", "tg_manager"))
TIMEZONE = os.getenv("TIMEZONE", "Asia/Tashkent")
STATS_CACHE_SECONDS = int(os.getenv("STATS_CACHE_SECONDS", "300"))

# Statistika hisoblashda Telegram API'ni ortiqcha yuklamaslik uchun cheklovlar
ACTIVITY_DAYS = 7
MAX_ACTIVE_DIALOGS = 150      # oxirgi 7 kunda faol bo'lgan nechta chat ko'rib chiqiladi
MAX_MESSAGES_PER_DIALOG = 3000

AUTOREPLY_FILE = BASE_DIR / "autoreply.json"
FRONTEND_DIR = BASE_DIR.parent / "frontend"
