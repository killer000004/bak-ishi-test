"""Bir martalik login: Telegram sessiya faylini yaratadi.

Ishga tushirish (server TO'XTATILGAN holatda):
    python login.py

Ikki usul:
  1) QR kod (tavsiya): telefonda Settings > Devices > Link Desktop Device orqali skanerlaysiz
  2) Telefon raqam + Telegram'ga kelgan kod
2FA yoqilgan bo'lsa, parol so'raladi (ekranda ko'rinmaydi).
"""
import asyncio
import getpass
import sys

import qrcode
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError

from config import API_HASH, API_ID, SESSION_PATH

# Windows konsolida QR bloklari to'g'ri chiqishi uchun
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def print_qr(url: str) -> None:
    qr = qrcode.QRCode(border=2)
    qr.add_data(url)
    qr.make(fit=True)
    qr.print_ascii(invert=True)


async def login_with_qr(client: TelegramClient) -> None:
    qr_login = await client.qr_login()
    print("\nTelefoningizda: Settings > Devices > Link Desktop Device, keyin quyidagi QR'ni skanerlang.")
    print("QR ~30 soniyada yangilanadi.\n")
    while True:
        print_qr(qr_login.url)
        try:
            await qr_login.wait(timeout=30)
            return
        except asyncio.TimeoutError:
            await qr_login.recreate()
            print("\nQR yangilandi:\n")
        except SessionPasswordNeededError:
            await client.sign_in(password=getpass.getpass("2FA paroli (ekranda ko'rinmaydi): "))
            return


async def main() -> None:
    client = TelegramClient(SESSION_PATH, API_ID, API_HASH, device_model="TG Manager", app_version="1.0")
    await client.connect()

    if await client.is_user_authorized():
        me = await client.get_me()
        print(f"Sessiya allaqachon bor: {me.first_name} (@{me.username or '-'}). Qayta login shart emas.")
        await client.disconnect()
        return

    choice = input("Login usuli: [1] QR kod (tavsiya)  [2] Telefon raqam va kod  > ").strip() or "1"
    if choice == "1":
        await login_with_qr(client)
    else:
        await client.start(password=lambda: getpass.getpass("2FA paroli (ekranda ko'rinmaydi): "))

    me = await client.get_me()
    print(f"\nOK: {me.first_name} (@{me.username or '-'}): sessiya saqlandi: {SESSION_PATH}.session")
    print("DIQQAT: .session fayli akkauntingizga to'liq kirish beradi. Hech kimga bermang, git'ga qo'shmang.")
    await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
