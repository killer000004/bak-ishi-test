"""TG Manager backend: FastAPI + Telethon (userbot).

Lokal ishga tushirish:
    uvicorn main:app --host 127.0.0.1 --port 8000
Serverda systemd orqali ishlaydi (deploy/tg-manager.service).
Faqat 1 ta worker ishlating (bitta Telegram sessiyasi bor).
"""
import asyncio
import logging
import secrets
import time
from collections import Counter
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from fastapi import Depends, FastAPI, File, Header, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from telethon import TelegramClient, errors, functions, types

import config
from autoreply import AutoReply

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("tg-manager")

TZ = ZoneInfo(config.TIMEZONE)

# flood_sleep_threshold=10: 10 soniyadan uzoq FloodWait bo'lsa kutmasdan 429 qaytaramiz
client = TelegramClient(config.SESSION_PATH, config.API_ID, config.API_HASH, flood_sleep_threshold=10)
autoreply = AutoReply(client, config.AUTOREPLY_FILE, config.TIMEZONE)


@asynccontextmanager
async def lifespan(_: FastAPI):
    await client.connect()
    if not await client.is_user_authorized():
        await client.disconnect()
        raise RuntimeError("Telegram sessiyasi topilmadi. Avval serverni to'xtatib: python login.py")
    autoreply.register()
    me = await client.get_me()
    log.info("Telegram'ga ulandi: %s (@%s)", me.first_name, me.username)
    yield
    await client.disconnect()


app = FastAPI(title="TG Manager", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)


# ---------------------------------------------------------------- xavfsizlik header'lari
# Panel internetga ochiq bo'lgani uchun: brauzer faqat ruxsat berilgan manbalardan kod yuklaydi,
# token esa faqat shu domenga yuboriladi (connect-src 'self').
CSP = "; ".join([
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://cdn.jsdelivr.net",
    "style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://fonts.googleapis.com",
    "font-src https://cdnjs.cloudflare.com https://fonts.gstatic.com",
    "img-src 'self' data: blob:",
    "connect-src 'self'",
    "frame-ancestors 'none'",
    "base-uri 'none'",
    "form-action 'self'",
])


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["Content-Security-Policy"] = CSP
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    if request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"
    return response


# ---------------------------------------------------------------- CORS (GitHub Pages frontend uchun)
if config.ALLOWED_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=config.ALLOWED_ORIGINS,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
        allow_headers=["Authorization", "Content-Type"],
        allow_private_network=True,  # https sayt -> http://127.0.0.1 ga ulanishiga Chrome ruxsati
        max_age=600,
    )
    log.info("CORS ruxsat berilgan: %s", ", ".join(config.ALLOWED_ORIGINS))


# ---------------------------------------------------------------- auth
# Brute-force himoyasi: bitta IP'dan 15 daqiqada 10 ta noto'g'ri token bo'lsa, vaqtincha bloklanadi.
# Haqiqiy IP WAF yuborgan X-Forwarded-For'dan olinadi (uvicorn --proxy-headers).
MAX_FAILED_ATTEMPTS = 10
FAILED_WINDOW_SECONDS = 15 * 60
_failed_attempts: dict[str, list[float]] = {}


def require_token(request: Request, authorization: str = Header(default="")) -> None:
    ip = request.client.host if request.client else "unknown"
    now = time.monotonic()
    recent = [t for t in _failed_attempts.get(ip, []) if now - t < FAILED_WINDOW_SECONDS]
    if len(recent) >= MAX_FAILED_ATTEMPTS:
        raise HTTPException(status_code=429, detail="Juda ko'p noto'g'ri urinish. 15 daqiqadan keyin qayta urinib ko'ring")

    token = authorization.removeprefix("Bearer ").strip()
    if not token or not secrets.compare_digest(token.encode(), config.ADMIN_TOKEN.encode()):
        recent.append(now)
        _failed_attempts[ip] = recent
        log.warning("Noto'g'ri token: ip=%s urinish=%d", ip, len(recent))
        raise HTTPException(status_code=401, detail="Token noto'g'ri yoki kiritilmagan")
    _failed_attempts.pop(ip, None)


AUTH = [Depends(require_token)]


# ---------------------------------------------------------------- Telegram xatolari
ERROR_TEXT = {
    "UsernameOccupiedError": "Bu username band",
    "UsernameInvalidError": "Username noto'g'ri",
    "UsernamePurchaseAvailableError": "Bu username faqat Fragment orqali sotib olinadi",
    "AboutTooLongError": "Bio juda uzun",
    "FirstnameInvalidError": "Ism noto'g'ri",
    "FreshResetAuthorisationForbiddenError": "Bu backend sessiyasi 24 soatdan yangi — Telegram boshqa seanslarni yakunlashga ruxsat bermaydi",
    "HashInvalidError": "Seans topilmadi (allaqachon yakunlangan bo'lishi mumkin)",
    "PhotoCropSizeSmallError": "Rasm juda kichik",
    "PhotoInvalidDimensionsError": "Rasm o'lchami noto'g'ri",
}


@app.exception_handler(errors.RPCError)
async def telegram_error_handler(_, exc: errors.RPCError):
    if isinstance(exc, errors.FloodWaitError):
        return JSONResponse(status_code=429, content={"detail": f"Telegram cheklovi: {exc.seconds} soniya kuting"})
    name = type(exc).__name__
    log.warning("Telegram xatosi: %s", exc)
    return JSONResponse(status_code=400, content={"detail": ERROR_TEXT.get(name, f"Telegram xatosi: {name}")})


# ---------------------------------------------------------------- helpers
def mask_phone(phone: str | None) -> str | None:
    if not phone:
        return None
    return f"+{phone[:3]} {'*' * max(len(phone) - 5, 0)}{phone[-2:]}"


def active_username(user: types.User) -> str:
    if user.username:
        return user.username
    for u in user.usernames or []:  # collectible (Fragment) usernamelar
        if u.active:
            return u.username
    return ""


async def build_me() -> dict:
    full = await client(functions.users.GetFullUserRequest("me"))
    user: types.User = full.users[0]
    password = await client(functions.account.GetPasswordRequest())
    return {
        "id": user.id,
        "first_name": user.first_name or "",
        "last_name": user.last_name or "",
        "username": active_username(user),
        "bio": full.full_user.about or "",
        "phone": mask_phone(user.phone),
        "premium": bool(user.premium),
        "has_photo": isinstance(user.photo, types.UserProfilePhoto),
        "two_fa": bool(password.has_password),
    }


# ---------------------------------------------------------------- health / profil
@app.get("/api/health", dependencies=AUTH)
async def health():
    me = await client.get_me()
    username = active_username(me)
    return {"ok": True, "label": f"@{username}" if username else (me.first_name or str(me.id))}


@app.get("/api/me", dependencies=AUTH)
async def get_me():
    return await build_me()


@app.get("/api/me/photo", dependencies=AUTH)
async def get_my_photo():
    data = await client.download_profile_photo("me", file=bytes)
    if not data:
        raise HTTPException(status_code=404, detail="Profil rasmi yo'q")
    return Response(content=data, media_type="image/jpeg", headers={"Cache-Control": "no-store"})


MAX_PHOTO_BYTES = 5 * 1024 * 1024


@app.post("/api/me/photo", dependencies=AUTH)
async def upload_my_photo(file: UploadFile = File(...)):
    if file.content_type not in ("image/jpeg", "image/png"):
        raise HTTPException(status_code=400, detail="Faqat JPG yoki PNG")
    data = await file.read(MAX_PHOTO_BYTES + 1)
    if len(data) > MAX_PHOTO_BYTES:
        raise HTTPException(status_code=413, detail="Rasm 5 MB dan oshmasin")
    uploaded = await client.upload_file(data, file_name=file.filename or "avatar.jpg")
    await client(functions.photos.UploadProfilePhotoRequest(file=uploaded))
    return {"ok": True}


USERNAME_RE = r"^$|^[a-zA-Z][a-zA-Z0-9_]{3,30}[a-zA-Z0-9]$"


class ProfileIn(BaseModel):
    first_name: str = Field(min_length=1, max_length=64)
    last_name: str = Field(default="", max_length=64)
    username: str = Field(default="", max_length=32, pattern=USERNAME_RE)
    bio: str = Field(default="", max_length=140)


@app.patch("/api/profile", dependencies=AUTH)
async def update_profile(p: ProfileIn):
    me = await client.get_me()
    bio_limit = 140 if me.premium else 70
    if len(p.bio) > bio_limit:
        raise HTTPException(status_code=400, detail=f"Bio {bio_limit} belgidan oshmasin")

    await client(functions.account.UpdateProfileRequest(
        first_name=p.first_name.strip(), last_name=p.last_name.strip(), about=p.bio,
    ))
    if p.username.lower() != active_username(me).lower():
        await client(functions.account.UpdateUsernameRequest(username=p.username))
    return await build_me()


# ---------------------------------------------------------------- statistika
_stats_cache: dict = {"at": 0.0, "data": None}
_stats_lock = asyncio.Lock()


async def compute_stats() -> dict:
    local_today = datetime.now(TZ).date()
    days = [local_today - timedelta(days=i) for i in range(config.ACTIVITY_DAYS - 1, -1, -1)]
    since = datetime.combine(days[0], datetime.min.time(), TZ)

    contacts = await client(functions.contacts.GetContactsRequest(hash=0))

    kinds = Counter(private=0, groups=0, channels=0, bots=0)
    unread_chats = unread_messages = 0
    managed_channels: list[types.Channel] = []
    active_dialogs = []

    async for d in client.iter_dialogs():
        e = d.entity
        if isinstance(e, types.User):
            if e.is_self:
                continue  # Saved Messages alohida hisoblanadi
            kinds["bots" if e.bot else "private"] += 1
        elif isinstance(e, types.Chat):
            kinds["groups"] += 1
        elif isinstance(e, types.Channel):
            if e.megagroup or e.gigagroup:
                kinds["groups"] += 1
            else:
                kinds["channels"] += 1
                if e.creator or e.admin_rights:
                    managed_channels.append(e)

        if d.unread_count:
            unread_chats += 1
            unread_messages += d.unread_count
        # Faol chat = oxirgi 7 kunda xabar bo'lgan shaxsiy chat yoki guruh (broadcast kanallar emas)
        is_broadcast = isinstance(e, types.Channel) and not (e.megagroup or e.gigagroup)
        if d.date and d.date >= since and not is_broadcast:
            active_dialogs.append(d)

    subscribers = 0
    for ch in managed_channels:
        full = await client(functions.channels.GetFullChannelRequest(ch))
        subscribers += full.full_chat.participants_count or 0

    saved = await client.get_messages("me", limit=0)
    saved_media = await client.get_messages("me", limit=0, filter=types.InputMessagesFilterPhotoVideo())
    saved_docs = await client.get_messages("me", limit=0, filter=types.InputMessagesFilterDocument())

    # Faollik: shaxsiy chatlarda kiruvchi+chiquvchi, guruhlarda faqat o'zingizniki
    sent_by_day: Counter = Counter()
    incoming_by_hour = [0] * 24
    outgoing_by_hour = [0] * 24
    truncated = len(active_dialogs) > config.MAX_ACTIVE_DIALOGS

    for d in active_dialogs[: config.MAX_ACTIVE_DIALOGS]:
        e = d.entity
        is_private = isinstance(e, types.User)
        kwargs = {} if is_private else {"from_user": "me"}
        count = 0
        async for m in client.iter_messages(e, limit=config.MAX_MESSAGES_PER_DIALOG, **kwargs):
            if m.date < since:
                break
            count += 1
            if m.action:  # servis xabarlar (qo'shildi, chiqdi...)
                continue
            local = m.date.astimezone(TZ)
            if m.out:
                sent_by_day[local.date()] += 1
                outgoing_by_hour[local.hour] += 1
            else:
                incoming_by_hour[local.hour] += 1
        if count >= config.MAX_MESSAGES_PER_DIALOG:
            truncated = True

    active_7d = len(active_dialogs)

    return {
        "contacts": len(contacts.contacts),
        "dialogs": dict(kinds),
        "dialogs_total": sum(kinds.values()),
        "active_chats_7d": active_7d,
        "unread_chats": unread_chats,
        "unread_messages": unread_messages,
        "managed_channels": len(managed_channels),
        "managed_subscribers": subscribers,
        "saved_messages": saved.total,
        "saved_files": saved_media.total + saved_docs.total,
        "activity": {"days": [d.isoformat() for d in days], "sent": [sent_by_day[d] for d in days]},
        "hourly": {"incoming": incoming_by_hour, "outgoing": outgoing_by_hour},
        "truncated": truncated,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/api/stats", dependencies=AUTH)
async def get_stats(refresh: bool = False):
    async with _stats_lock:  # bir vaqtda faqat bitta hisoblash
        fresh = time.monotonic() - _stats_cache["at"] < config.STATS_CACHE_SECONDS
        if _stats_cache["data"] and fresh and not refresh:
            return _stats_cache["data"]
        data = await compute_stats()
        _stats_cache.update(at=time.monotonic(), data=data)
        return data


# ---------------------------------------------------------------- seanslar
@app.get("/api/sessions", dependencies=AUTH)
async def get_sessions():
    res = await client(functions.account.GetAuthorizationsRequest())
    items = [
        {
            "hash": str(a.hash),  # 64-bit — JS'da son sifatida buziladi, shuning uchun string
            "current": bool(a.current),
            "device": a.device_model,
            "platform": a.platform,
            "system": a.system_version,
            "app": f"{a.app_name} {a.app_version}".strip(),
            "official": bool(a.official_app),
            "ip": a.ip,
            "location": ", ".join(x for x in (a.region, a.country) if x),
            "active_at": a.date_active.isoformat(),
            "created_at": a.date_created.isoformat(),
        }
        for a in res.authorizations
    ]
    items.sort(key=lambda s: s["active_at"], reverse=True)
    items.sort(key=lambda s: not s["current"])  # hozirgi seans birinchi
    return items


# /others ni /{hash} dan OLDIN e'lon qilish shart
@app.delete("/api/sessions/others", dependencies=AUTH)
async def terminate_other_sessions():
    await client(functions.auth.ResetAuthorizationsRequest())
    return {"ok": True}


@app.delete("/api/sessions/{session_hash}", dependencies=AUTH)
async def terminate_session(session_hash: int):
    if session_hash == 0:
        raise HTTPException(status_code=400, detail="Hozirgi seansni bu yerdan yakunlab bo'lmaydi")
    await client(functions.account.ResetAuthorizationRequest(hash=session_hash))
    return {"ok": True}


# ---------------------------------------------------------------- avto-javob
class AutoReplyIn(BaseModel):
    enabled: bool
    contacts_only: bool = True
    text: str = Field(min_length=1, max_length=4096)


@app.get("/api/autoreply", dependencies=AUTH)
async def get_autoreply():
    return autoreply.get()


@app.put("/api/autoreply", dependencies=AUTH)
async def put_autoreply(body: AutoReplyIn):
    return autoreply.save(body.model_dump())


# ---------------------------------------------------------------- frontend (oxirida!)
app.mount("/", StaticFiles(directory=config.FRONTEND_DIR, html=True), name="ui")
