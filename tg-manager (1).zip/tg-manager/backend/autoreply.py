"""Avto-javob: faqat shaxsiy chatlarda, har bir odamga cooldown ichida 1 marta.

DIQQAT: userbot orqali avto-javob Telegram tomonidan spam deb baholanishi mumkin.
Standart holatda o'chiq va faqat kontaktlarga javob beradi.
"""
import json
import logging
import time
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from telethon import TelegramClient, events, types

log = logging.getLogger("autoreply")

TELEGRAM_SERVICE_ID = 777000

DEFAULTS = {
    "enabled": False,
    "contacts_only": True,
    "cooldown_hours": 12,
    "text": "Assalomu alaykum! Hozir bandman, bo'shashim bilan javob beraman.",
}


class AutoReply:
    def __init__(self, client: TelegramClient, path: Path, tz: str):
        self.client = client
        self.path = path
        self.tz = ZoneInfo(tz)
        self.cfg = self._load()
        self._last_sent: dict[int, float] = {}  # user_id -> unix time (restartda tozalanadi)

    def _load(self) -> dict:
        cfg = dict(DEFAULTS)
        try:
            cfg.update(json.loads(self.path.read_text("utf-8")))
        except FileNotFoundError:
            pass
        except (json.JSONDecodeError, OSError) as e:
            log.warning("autoreply.json o'qilmadi: %s", e)
        return cfg

    def get(self) -> dict:
        return dict(self.cfg)

    def save(self, data: dict) -> dict:
        self.cfg.update(data)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.cfg, ensure_ascii=False, indent=2), "utf-8")
        tmp.replace(self.path)
        return self.get()

    def register(self) -> None:
        self.client.add_event_handler(
            self._on_message, events.NewMessage(incoming=True, func=lambda e: e.is_private)
        )

    async def _on_message(self, event: events.NewMessage.Event) -> None:
        cfg = self.cfg
        if not cfg["enabled"]:
            return
        try:
            sender = await event.get_sender()
            if not isinstance(sender, types.User):
                return
            if sender.bot or sender.is_self or sender.support or sender.id == TELEGRAM_SERVICE_ID:
                return
            if cfg["contacts_only"] and not sender.contact:
                return

            now = time.time()
            if now - self._last_sent.get(sender.id, 0) < cfg["cooldown_hours"] * 3600:
                return
            self._last_sent[sender.id] = now

            text = (
                cfg["text"]
                .replace("{first_name}", sender.first_name or "")
                .replace("{time}", datetime.now(self.tz).strftime("%H:%M"))
            )
            await event.respond(text)
        except Exception:  # handler yiqilsa ham server ishlashda davom etadi
            log.exception("Avto-javob yuborilmadi")
